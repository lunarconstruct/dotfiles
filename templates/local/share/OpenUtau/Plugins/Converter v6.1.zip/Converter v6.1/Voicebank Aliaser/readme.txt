This program will work on CV (consonant-vowel) oto.ini files only.

Instructions on use:
1. Move the oto file from the voicebank folder to the Voicebank Aliaser folder.
2. To add hiragana aliases to a romaji oto, run the "Add Hiragana Aliases" batch file.
3. To add romaji aliases to a hiragana oto, run the "Add Romaji Aliases" batch file.
4. Move the oto file back to the voicebank folder.
5. You're done!