Chiepomme's romaji/hiragana plugin is built so that it can easily have its scripts replaced. Thus,
this kit contains tables with updated romanization and kana sets to make the plugin easier to use.

These charts will be updated as necessary to patch for any potential missed kana or anything else.

You may find the necessary plugins here: http://www.box.com/s/68sehsh5cep6dzkzvfp8

First, download the plugin entitled "���[�}�����Ђ炪��.uar". Open the UTAU editor and drag and drop the
UAR file into the editor, then click OK.

Navigate to the plugins directory in UTAU and find the folder entitled ���[�}�����Ђ炪��, and open it.

Replace the text file named "table.txt" in there with "romaji to hiragana.txt".

Next, ownload the plugin entitled "�Ђ炪�ȁ����[�}��.uar". Open the UTAU editor and drag and drop the
UAR file into the editor, then click OK.

Navigate to the plugins directory in UTAU and find the folder entitled �Ђ炪�ȁ����[�}��, and open it.

Replace the text file named "table.txt" in there with the file "hiragana to romaji.txt".

To use the plugin, when editing a UST, select the area you wish to convert, then run the
corresponding plugin.