This program is for making ust files to test UTAU voicebanks.
The ust files it makes contain one note for each voicebank sample present in a given oto.ini file.

Start the program, then open the oto.ini file that is associated with the voicebank you want to test.

Press the 'Generate' button and select the filename you want the ust to have.

