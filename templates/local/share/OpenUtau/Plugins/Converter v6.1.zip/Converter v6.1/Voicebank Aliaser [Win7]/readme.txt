This program will work on CV (consonant-vowel) oto.ini files only.

Drag and drop the UST you would like to convert on the appropriate batch file.