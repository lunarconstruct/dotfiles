Arpasing Assistant
Copyright (C) 2016-2017, Kanru Hua. All rights reserved.

Arpasing Assistant is an UTAU plugin for creating English songs based on the
  Arpasing recording standard.

Website: http://web.engr.illinois.edu/~khua5/index.php/moresampler/
  (part of the series on Moresampler)

Contact the author
===

Email: k.hua.kanru [at] ieee.org

